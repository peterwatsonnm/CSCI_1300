/*
Car:
The car class stores the attributes and actions of your current vehicle.
These include amount of fuel, horsepower/speed (which can be improved with upgrades),
as well as possibly attack/defensive mods
  Health
  Horsepower
  boolean values to represent the status of the car
    hasflattires
    is driving
    is broken

*/


using namespace std;
#include <string>

#ifndef CAR_H
#define CAR_H

class Car
{
private:
  bool engineRuns;
  bool tiresFlat;
  bool isBurning;
  int horsepower;
  string engine;
  string model;
  int gas;
public:
  Car();
  Car(int newHorse, string engine1, string type, int gas);
  int setHorsepower(int newHorse);
  void setEngine(string newEngine);
  void setGas(int newGas);
  void breakEngine();
  void flattenTires();
  void setFire();
  bool doesEngineRun();
  bool areTiresFlat();
  bool isCarBurning();
  int getHorsepower();
  string getEngine();
  string getModel();
  int getGas();

};

#endif
