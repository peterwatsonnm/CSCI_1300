// CS1300 Fall 2019
// Author: Peter Watson 
// Recitation: 103 Telly Umada
// Homework 2 - Problem 1 -- hello world

#include <iostream> 
using namespace std; 

int main()
{
	cout << "Hello, World!" << endl;
		
	return 0;
}